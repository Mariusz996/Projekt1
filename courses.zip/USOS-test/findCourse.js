const request = require('request');

const findCourse = (courseToFind) => {
    request(`https://usosapps.umk.pl/services/courses/search?name="${courseToFind}"`, function (error, response, body) {
        if (error) {
            console.log('Cannot connect with website');
            return;
        } else {
          let recivedDataFromServer = JSON.parse(body);
          let course = recivedDataFromServer.items;
            
  
          for(let i=0; i < course.length; i++){
            console.log(course[i].course_id + ',' + course[i].match);
          }
        }
    });
}

module.exports.findCourse = findCourse;


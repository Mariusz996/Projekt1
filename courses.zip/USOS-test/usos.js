/*
##########  Skrypt zwracajacy liste kursow, w formacie JSON  ##########  
Wywołanie skryptu:
np. node usos.js -c "Python"
    
*/

const program = require('commander');
const findCourse = require('./findCourse');
program.option('-c --course [type]').parse(process.argv);

const courseName = program.course;
//console.log(courseName);
findCourse.findCourse(courseName);
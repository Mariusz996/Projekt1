// uruchomienei programu: node app.js 'nazwisko'

/*
plik keys.js :

const consumer = {
    key: "TWOJ CONSUMER KEY",
    secret: "TWOJ CONSUMER SECRET"
}

module.exports.consumer = consumer;
*/

const express = require('express');
const request = require('request');
const qs = require('querystring');
const yargs = require('yargs');
const keys = require('./keys.js');


const argv = yargs.argv;
const nazwisko = process.argv[2];

// console.log(nazwisko);

let app = express();

let oauth = {
        callback: 'http://127.0.0.1:3000/callback',
        consumer_key: keys.consumer.key, // TWOJ CONSUMER KEY
        consumer_secret: keys.consumer.secret // TWOJ CONSUMER SECRET
    },
    url = 'https://usosapps.umk.pl/services/oauth/request_token';

request.post({
    url: url,
    oauth: oauth
}, function (e, r, body) {
    let req_data = qs.parse(body);
    let uri = 'https://usosapps.umk.pl/services/oauth/authorize' + '?' + qs.stringify({
        oauth_token: req_data.oauth_token
    });

    console.log(uri);

    app.get('/callback', function (req, res) {
        res.send('Hello My USOS World');
        let verifier = qs.parse(req.originalUrl).oauth_verifier;
        let auth_data = qs.parse(body);
        let oauth = {
            consumer_key: keys.consumer.key, // TWOJ CONSUMER KEY
            consumer_secret: keys.consumer.secret, // TWOJ CONSUMER SECRET
            token: auth_data.oauth_token,
            token_secret: req_data.oauth_token_secret,
            verifier: verifier
        };
        let url = 'https://usosapps.umk.pl/services/oauth/access_token';

        request.post({
            url: url,
            oauth: oauth
        }, function (e, r, body) {
            let perm_data = qs.parse(body);
            let oauth = {
                consumer_key: keys.consumer.key, // TWOJ CONSUMER KEY
                consumer_secret: keys.consumer.secret, // TWOJ CONSUMER SECRET
                token: perm_data.oauth_token,
                token_secret: perm_data.oauth_token_secret
            };

            let url = `https://usosapps.umk.pl/services/users/search?name="${nazwisko}"`;

            // ##### MOJE ŻĄDANIE ############
            if (!e) {
                request({
                    url: url,
                    oauth: oauth
                }, (error, response, body) => {
                    // console.log(url)
                    // console.log(body);
                    const user = JSON.parse(body); // zamienia string na obiekt JSON
                    // console.log(user);
                    console.log(`ID: ${user.items[0].user_id}, ${user.items[0].match}`);
                });
            } else {
                console.log('smt went wrong');
            }
            // ################################
            // console.log(oauth);
        });
    });
});

app.get('/', (req, res) => {
    res.send('Hello My USOS World');
});


app.listen(3000, () => {
    console.log('Example app listening on port 3000!');

});
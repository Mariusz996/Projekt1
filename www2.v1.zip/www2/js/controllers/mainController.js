app.controller('mainController', ['$scope', 'mainService', '$routeParams', function($scope, mainService, $routeParams) {
  var positionmap = [ [ 324, 700 ], [ 269, 676 ], [ 232, 591 ], [ 213, 550 ], [ 203, 530 ], [ 195, 502 ], [ 187, 485 ], [ 176, 476 ], [ 126, 481 ], [ 175, 454 ], [ 155, 435 ], [ 171, 419 ], [ 215, 407 ],
 ];
/*punkty na mapie*/ 
 mainService.success(function(data) {
    
    var i, points = [];
    for (i = 0; i < data.data.length; i = i + 1) {
        points.push(positionmap[data.data[i] - 1]);
    }
    $scope.data = points;
  });
}]);